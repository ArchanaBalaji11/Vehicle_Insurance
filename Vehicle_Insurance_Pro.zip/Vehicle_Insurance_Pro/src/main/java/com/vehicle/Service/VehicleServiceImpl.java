package com.vehicle.Service;

import com.vehicle.Model.Vehicle;
import com.vehicle.Repository.VehicleRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class VehicleServiceImpl implements VehicleService {

    private final VehicleRepository repo;

    public VehicleServiceImpl(VehicleRepository repo) {
        this.repo = repo;
    }

    @Override
    public List<Vehicle> getAllVehicles() {
        return repo.findAll();
    }

    @Override
    public Vehicle getVehicleById(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Vehicle not found with id: " + id));
    }

    @Override
    public Vehicle saveVehicle(Vehicle vehicle) {
        return repo.save(vehicle);
    }

    @Override
    public void deleteVehicle(Long id) {
        repo.deleteById(id);
    }
}
