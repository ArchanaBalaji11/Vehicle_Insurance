package com.vehicle.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.vehicle.Model.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
}

