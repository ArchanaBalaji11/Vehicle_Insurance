package com.vehicle.Service;

import com.vehicle.Model.User;

public interface UserService {
    User findByUsername(String username);
    User saveUser(User user);
}
