package com.vehicle.Controller;

import com.vehicle.Model.InsurancePolicy;
import com.vehicle.Service.InsurancePolicyService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/policies")
public class InsurancePolicyController {

    private final InsurancePolicyService policyService;

    public InsurancePolicyController(InsurancePolicyService policyService) {
        this.policyService = policyService;
    }

    @GetMapping
    public List<InsurancePolicy> all() {
        return policyService.getAllPolicies();
    }

    @GetMapping("/{id}")
    public InsurancePolicy get(@PathVariable Long id) {
        return policyService.getPolicyById(id);
    }

    @PostMapping
    public InsurancePolicy add(@RequestBody InsurancePolicy policy) {
        return policyService.savePolicy(policy);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        policyService.deletePolicy(id);
        return ResponseEntity.ok().build();
    }
}

