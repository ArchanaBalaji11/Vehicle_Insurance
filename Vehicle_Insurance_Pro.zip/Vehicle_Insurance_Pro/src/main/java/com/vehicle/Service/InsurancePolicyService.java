package com.vehicle.Service;

import com.vehicle.Model.InsurancePolicy;
import java.util.List;

public interface InsurancePolicyService {
    List<InsurancePolicy> getAllPolicies();
    InsurancePolicy getPolicyById(Long id);
    InsurancePolicy savePolicy(InsurancePolicy policy);
    void deletePolicy(Long id);
}
