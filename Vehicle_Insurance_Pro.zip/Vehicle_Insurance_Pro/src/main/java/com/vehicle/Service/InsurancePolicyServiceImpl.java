package com.vehicle.Service;

import com.vehicle.Model.InsurancePolicy;
import com.vehicle.Repository.InsurancePolicyRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class InsurancePolicyServiceImpl implements InsurancePolicyService {

    private final InsurancePolicyRepository policyRepository;

    public InsurancePolicyServiceImpl(InsurancePolicyRepository policyRepository) {
        this.policyRepository = policyRepository;
    }

    @Override
    public List<InsurancePolicy> getAllPolicies() {
        return policyRepository.findAll();
    }

    @Override
    public InsurancePolicy getPolicyById(Long id) {
        return policyRepository.findById(id).orElse(null);
    }

    @Override
    public InsurancePolicy savePolicy(InsurancePolicy policy) {
        return policyRepository.save(policy);
    }

    @Override
    public void deletePolicy(Long id) {
        policyRepository.deleteById(id);
    }
}

