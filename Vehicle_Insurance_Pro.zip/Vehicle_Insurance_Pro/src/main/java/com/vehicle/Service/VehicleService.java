package com.vehicle.Service;

import com.vehicle.Model.Vehicle;
import java.util.List;

public interface VehicleService {
    List<Vehicle> getAllVehicles();
    Vehicle getVehicleById(Long id);
    Vehicle saveVehicle(Vehicle vehicle);
    void deleteVehicle(Long id);
}

