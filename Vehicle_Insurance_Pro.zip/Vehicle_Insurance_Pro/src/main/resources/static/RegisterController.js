app.controller("RegisterController", function($scope, $http) {
    $scope.user = {};
    $scope.message = "";
    $scope.error = "";

    $scope.register = function() {
        $http.post("http://localhost:8080/auth/register", $scope.user)
            .then(function(response) {
                $scope.message = response.data;
                $scope.error = "";
            }, function(error) {
                $scope.error = "Error: " + error.data;
                $scope.message = "";
            });
    };
});
