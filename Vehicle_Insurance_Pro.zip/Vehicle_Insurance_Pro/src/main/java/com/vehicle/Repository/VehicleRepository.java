package com.vehicle.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.vehicle.Model.Vehicle;

public interface VehicleRepository extends JpaRepository<Vehicle, Long> {
}
