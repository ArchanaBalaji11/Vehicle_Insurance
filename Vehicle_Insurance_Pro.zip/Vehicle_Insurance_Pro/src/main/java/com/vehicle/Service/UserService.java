package com.vehicle.Service;

import com.vehicle.Model.User;

public interface UserService {
    User saveUser(User user);
    User findByUsername(String username);
}
