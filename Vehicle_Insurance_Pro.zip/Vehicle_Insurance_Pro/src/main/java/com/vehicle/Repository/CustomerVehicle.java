package com.vehicle.Repository;

public class CustomerVehicle {

}
