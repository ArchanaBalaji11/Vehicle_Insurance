package com.vehicle.Controller;

import com.vehicle.Model.User;
import com.vehicle.Service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class RegistrationController {

    private final UserService userService;

    public RegistrationController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody User user) {
        if (userService.findByUsername(user.getUsername()) != null) {
            return ResponseEntity
                    .badRequest()
                    .body("Username already exists!");
        }

        userService.saveUser(user);
        return ResponseEntity.ok("Registration successful!");
    }
}
