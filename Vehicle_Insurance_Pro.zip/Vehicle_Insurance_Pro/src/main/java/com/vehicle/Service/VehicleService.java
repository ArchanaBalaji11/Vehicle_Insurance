package com.vehicle.Service;

import com.vehicle.Model.Vehicle;
import java.util.List;

public interface VehicleService {
    List<Vehicle> getAllVehicles();
    Vehicle getVehicleById(Long id);
    Vehicle saveVehicle(Vehicle vehicle); // needed for save/add
    void deleteVehicle(Long id);         // needed for delete
}

