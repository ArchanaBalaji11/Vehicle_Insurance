var app = angular.module("vehicleApp", ["ngRoute"]);

app.config(function($routeProvider) {
    $routeProvider
        .when("/login", {
            templateUrl: "views/login.html",
            controller: "LoginController"
        })
        .when("/register", {
            templateUrl: "views/register.html",
            controller: "RegisterController"
        })
        .when("/dashboard", {
            templateUrl: "views/dashboard.html",
            controller: "DashboardController"
        })
        .when("/customers", {
            templateUrl: "views/customers.html",
            controller: "CustomerController"
        })
        .otherwise({
            redirectTo: "/login"
        });
});

// ================== Login Controller ==================
app.controller("LoginController", function($scope, $http, $location) {
    $scope.loginData = {};

    $scope.login = function() {
        $http.post("/api/auth/login", $scope.loginData)
            .then(function(response) {
                if (response.data.includes("Login successful")) {
                    $location.path("/dashboard");
                } else {
                    alert("Invalid credentials");
                }
            }, function() {
                alert("Error logging in");
            });
    };
});

// ================== Register Controller ==================
app.controller("RegisterController", function($scope, $http, $location) {
    $scope.registerData = {};

    $scope.register = function() {
        $http.post("/api/auth/register", $scope.registerData)
            .then(function(response) {
                alert("Registration successful! Please log in.");
                $location.path("/login");
            }, function() {
                alert("Error during registration");
            });
    };
});

// ================== Dashboard Controller ==================
app.controller("DashboardController", function($scope, $http) {
    $http.get("/api/dashboard").then(function(response) {
        $scope.message = response.data;
    });
});

// ================== Customers Controller ==================
app.controller("CustomerController", function($scope, $http) {
    $scope.customers = [];
    $scope.newCustomer = {};

    // Fetch all customers
    $http.get("/api/customers").then(function(response) {
        $scope.customers = response.data;
    });

    // Add new customer
    $scope.addCustomer = function() {
        $http.post("/api/customers", $scope.newCustomer)
            .then(function() {
                alert("Customer added successfully");
                $scope.newCustomer = {};
                return $http.get("/api/customers");
            })
            .then(function(response) {
                $scope.customers = response.data;
            });
    };
});

