package com.vehicle.Service;

import com.vehicle.Model.User;
import com.vehicle.Repository.UserRepository;
import org.springframework.security.core.userdetails.*;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService, UserDetailsService {

    private final UserRepository userRepository;

    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // ------------------- UserService methods -------------------
    @Override
    public User saveUser(User user) {
        return userRepository.save(user);
    }

    @Override
    public User findByUsername(String username) {
        return userRepository.findByUsername(username).orElse(null);
    }

    // ------------------- Spring Security method -------------------
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username)
                    .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        // Here, you can add roles if you have a roles table
        return new org.springframework.security.core.userdetails.User(
                user.getUsername(),
                user.getPassword(), // Must be BCrypt encoded
                List.of(new SimpleGrantedAuthority("ROLE_USER"))
        );
    }
}
