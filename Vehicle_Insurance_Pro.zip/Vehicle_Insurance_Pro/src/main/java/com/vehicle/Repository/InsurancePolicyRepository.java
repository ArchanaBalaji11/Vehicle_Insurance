package com.vehicle.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.vehicle.Model.InsurancePolicy;

public interface InsurancePolicyRepository extends JpaRepository<InsurancePolicy, Long> {
}
