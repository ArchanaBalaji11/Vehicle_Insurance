package com.vehicle.Service;

import com.vehicle.Model.InsurancePolicy;
import com.vehicle.Repository.InsurancePolicyRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InsurancePolicyServiceImpl implements InsurancePolicyService {

    private final InsurancePolicyRepository repo;

    public InsurancePolicyServiceImpl(InsurancePolicyRepository repo) {
        this.repo = repo;
    }

    @Override
    public List<InsurancePolicy> getAllPolicies() {
        return repo.findAll();
    }

    @Override
    public InsurancePolicy getPolicyById(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Policy not found with id: " + id));
    }

    @Override
    public InsurancePolicy savePolicy(InsurancePolicy policy) {
        return repo.save(policy);
    }

    @Override
    public void deletePolicy(Long id) {
        repo.deleteById(id);
    }
}
